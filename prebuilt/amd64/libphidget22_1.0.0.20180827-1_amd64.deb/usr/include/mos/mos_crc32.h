#ifndef _CRC32_H_
#define _CRC32_H_

MOSAPI uint32_t MOSCConv mos_crc32(uint32_t, const void *, uint64_t);

#endif /* _CRC32_H_ */
