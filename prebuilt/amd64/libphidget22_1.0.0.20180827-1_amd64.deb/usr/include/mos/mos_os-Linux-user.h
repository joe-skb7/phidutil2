#ifndef _MOS_OS_LINUXUSER_H_
#define _MOS_OS_LINUXUSER_H_

#include <stdarg.h>
#include <stdio.h>				/* for vsnprintf() */
#include <stdlib.h>				/* for malloc() */
#include <string.h>				/* for strlcpy() */

#endif /* _MOS_OS_LINUXUSER_H_ */
