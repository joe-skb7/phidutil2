#ifndef MOS_GETPASSWD_H_
#define MOS_GETPASSWD_H_

#include "mos_os.h"
#include "mos_iop.h"

MOSAPI int MOSCConv mos_getpasswd(mosiop_t, const char *, char *, size_t);

#endif /* MOS_GETPASSWD_H_ */
