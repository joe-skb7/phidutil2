#ifndef _MOS_ERROR_ERRNO_H_
#define _MOS_ERROR_ERRNO_H_

int mos_fromerrno(int);

#endif /* _MOS_ERROR_ERRNO_H_ */
