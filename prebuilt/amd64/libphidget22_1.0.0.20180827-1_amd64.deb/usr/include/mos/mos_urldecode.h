#ifndef _MOS_URLDECODE_H_
#define _MOS_URLDECODE_H_

MOSAPI uint32_t MOSCConv mos_urldecode(void *, uint32_t);

#endif /* _MOS_URLDECODE_H_ */
